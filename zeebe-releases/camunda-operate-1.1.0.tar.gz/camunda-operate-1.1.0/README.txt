This is a distribution of Operate 1.1.0

How to run
==========

Prerequisites:
1. Zeebe of version 0.21.0 is running with Elasticsearch exporter turned on. See https://zeebe.io/ on how to install and run Zeebe.
2. Elasticsearch of version 6.8.3 or higher is running: it can be either the same instance configured for Zeebe export, or a separate one. See https://www.elastic.co/products/elasticsearch on how to install and run Elasticsearch

To run Operate:
1. Adjust Operate configuration file config/application.yml to point to your Zeebe and Elasticsearch instances
2. Run bin/operate or bin/operate.bat, depending on your file system.